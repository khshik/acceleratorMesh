# Team Up

Добро пожаловать на страницу нашего проекта! Приложение находится в стадии доработки. Чтобы вам не пришлось скачивать zip-архив и делать всё локально, мы захостили наш проект на Github Pages. Увидеть наше приложение: https://khshik.github.io/acceleratorMesh/src/index.html

Презентация: https://docs.google.com/presentation/d/1-hisa3Mc-KBCCn90x0tD0KLm-toZEffCIZIqFN6hG2s/edit?usp=sharing

Если у вас есть вопросы или пожелания, пожалуйста, напишите нам по адресу khshik777@gmail.com :)
